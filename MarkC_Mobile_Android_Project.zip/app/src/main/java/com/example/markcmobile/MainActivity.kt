package com.example.markcmobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF0B0D12)
private val Surface = Color(0xFF151922)
private val Accent = Color(0xFF6C8CFF)
private val Muted = Color(0xFF9AA4B5)
private val TextMain = Color(0xFFF4F6FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("markc_mobile", MODE_PRIVATE)
        setContent {
            var sensitivity by remember { mutableFloatStateOf(prefs.getFloat("sensitivity", 1f)) }
            var acceleration by remember { mutableFloatStateOf(prefs.getFloat("acceleration", 0f)) }
            var dpi by remember { mutableFloatStateOf(prefs.getFloat("dpi", 100f)) }
            var saved by remember { mutableStateOf(false) }

            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent,
                    background = Background,
                    surface = Surface,
                    onBackground = TextMain,
                    onSurface = TextMain
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = Background) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier.size(52.dp).background(Accent.copy(alpha = .16f), RoundedCornerShape(16.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Mouse, contentDescription = null, tint = Accent, modifier = Modifier.size(28.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("MarkC Mobile", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = TextMain)
                                Text("Mouse tuning • Android companion", fontSize = 12.sp, color = Muted)
                            }
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = Accent, modifier = Modifier.size(24.dp))
                        }

                        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("SEU PERFIL", fontSize = 11.sp, color = Accent, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                Text("Configuração personalizada", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                                Text("Ajuste os valores abaixo e salve seu perfil neste aparelho.", color = Muted, fontSize = 13.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    PresetButton("Precisão") {
                                        sensitivity = 0.85f; acceleration = 0f; dpi = 100f; saved = false
                                    }
                                    PresetButton("Equilibrado") {
                                        sensitivity = 1f; acceleration = 0.25f; dpi = 125f; saved = false
                                    }
                                    PresetButton("Rápido") {
                                        sensitivity = 1.25f; acceleration = 0.5f; dpi = 100f; saved = false
                                    }
                                }
                            }
                        }

                        SettingCard(title = "Sensibilidade", subtitle = "Fator de escala do ponteiro", value = String.format("%.2fx", sensitivity)) {
                            Slider(value = sensitivity, onValueChange = { sensitivity = it; saved = false }, valueRange = 0.25f..3f)
                            SliderLabels("0,25x", "3,00x")
                        }
                        SettingCard(title = "Aceleração", subtitle = "Nível simulado para o perfil", value = "${(acceleration * 100).toInt()}%") {
                            Slider(value = acceleration, onValueChange = { acceleration = it; saved = false }, valueRange = 0f..1f)
                            SliderLabels("Desligada", "Alta")
                        }
                        SettingCard(title = "Escala de exibição", subtitle = "Valor de referência do perfil", value = "${dpi.toInt()}%") {
                            Slider(value = dpi, onValueChange = { dpi = it; saved = false }, valueRange = 75f..200f, steps = 4)
                            SliderLabels("75%", "200%")
                        }

                        Button(
                            onClick = {
                                prefs.edit().putFloat("sensitivity", sensitivity)
                                    .putFloat("acceleration", acceleration)
                                    .putFloat("dpi", dpi).apply()
                                saved = true
                            },
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (saved) "Perfil salvo" else "Salvar perfil", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = {
                                sensitivity = 1f; acceleration = 0f; dpi = 100f; saved = false
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.RestartAlt, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Restaurar valores padrão")
                        }

                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF241F14)), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Importante", color = Color(0xFFFFD27A), fontWeight = FontWeight.Bold)
                                Text(
                                    "Esta é uma interface de perfil para Android. Ela não altera o Registro do Windows nem aplica a curva original do MarkC Mouse Fix. Os controles servem para guardar suas preferências; o efeito real depende do dispositivo e do suporte do Android.",
                                    color = Color(0xFFE2D6B9), fontSize = 12.sp, lineHeight = 18.sp
                                )
                            }
                        }
                        Text("MarkC Mobile • versão 1.0 • projeto comunitário não oficial", color = Muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                    }
                }
            }
        }
    }
}

@Composable
private fun PresetButton(label: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.height(40.dp), contentPadding = PaddingValues(horizontal = 12.dp), shape = RoundedCornerShape(12.dp)) {
        Text(label, fontSize = 11.sp)
    }
}

@Composable
private fun SettingCard(title: String, subtitle: String, value: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, fontSize = 12.sp, color = Muted)
                }
                Text(value, fontSize = 16.sp, color = Accent, fontWeight = FontWeight.Bold)
            }
            content()
        }
    }
}

@Composable
private fun SliderLabels(left: String, right: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(left, color = Muted, fontSize = 11.sp)
        Text(right, color = Muted, fontSize = 11.sp)
    }
}
