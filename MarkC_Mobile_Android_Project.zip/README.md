# MarkC Mobile — Android project

Projeto de interface Android inspirado no conceito do MarkC Mouse Fix.

## O que contém
- Interface escura e responsiva em Jetpack Compose.
- Controles de sensibilidade, aceleração simulada e escala de exibição.
- Perfis rápidos: Precisão, Equilibrado e Rápido.
- Salva os valores localmente no aparelho.

## Limitações importantes
Este app **não aplica** a correção original do MarkC, não altera o Registro do Windows e não consegue garantir mudança real na aceleração do mouse no Android. Os valores são preferências guardadas no aplicativo.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `MarkC_Mobile_Android_Project` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se necessário, instale o Android SDK 35 pelo SDK Manager.
5. Selecione **Build > Build APK(s)**.
6. O APK de depuração normalmente aparece em `app/build/outputs/apk/debug/app-debug.apk`.

Requer conexão com a internet na primeira sincronização para baixar dependências Gradle.
